//==================================================================================
// sample js for sample-dialog.html
//==================================================================================
pb.alert("let's take some move..")
pb.api( 'position', { left:80, top:80 } )
pb.sleep(500)
pb.api( 'position', { left:280, top:180 } )
pb.sleep(500)
pb.api( 'position', { left:380, top:280 } )
pb.sleep(500)
pb.api( 'position', { left:480, top:380 } )
pb.sleep(500)
 